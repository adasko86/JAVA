package Fluence;

public class EmailMessage {
	private String from;
    private String to;
    private String subject;
    private String content;
    private String mimeType; 
    
    private EmailMessage() {}

    public static Builder builder() {
        return new EmailMessage.Builder();
    }

    public static class Builder {
        private EmailMessage instance = new EmailMessage();

        private Builder() {
        }

        public Builder from(String from) {
            instance.from = from;
            return this;
        }

        public Builder to(String to) {
            instance.to = to;
            return this;
        }

        public Builder subject(String subject) {
            instance.subject = subject;
            return this;
        }

        public Builder content(String content) {
            instance.content = content;
            return this;
        }

        public Builder mimeType(String mimeTypeName) {
            instance.mimeType = mimeTypeName;
            return this;
        }

        public EmailMessage build() {
            return instance;
        }
    }
    
    @Override
    public String toString() {
    	System.out.println("Content: " + content);
    	System.out.println("From: " + from);
    	System.out.println("To: " + to);
    	System.out.println("Subject: " + subject);
    	System.out.println("MimeType: " + mimeType);
    	return super.toString();
    }
}

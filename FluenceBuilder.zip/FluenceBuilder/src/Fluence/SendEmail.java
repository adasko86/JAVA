package Fluence;

public class SendEmail {

	public static void main(String[] args) {
		EmailMessage emailMessage = 
			EmailMessage.builder()
		        .from("abc@example.com")
		        .to("bca@example.com")
		        .subject("Hello my friend")
		        .content("Some content")
		        .build();

		emailMessage.toString();
	}

}

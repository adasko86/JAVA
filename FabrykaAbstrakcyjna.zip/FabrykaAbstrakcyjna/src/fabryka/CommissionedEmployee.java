package fabryka;

public class CommissionedEmployee extends Employee {

	EmployeeRecord employeeRecord = null;
	Money money;
	public Money getMoney() {
		return money;
	}

	public void setMoney(Money _money) {
		this.money = _money;
	}
	public CommissionedEmployee(EmployeeRecord record) {
		employeeRecord = record;
	}

	@Override
	public boolean isPayday() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Money calculatePay() {
		// TODO Auto-generated method stub
		setMoney(new Money(2500));
		return this.money;
	}

	@Override
	public void deliverPay() {
		// TODO Auto-generated method stub
		System.out.println("Wyp�a�: " + getMoney().getPayment()  + " z�otych");
	}

}

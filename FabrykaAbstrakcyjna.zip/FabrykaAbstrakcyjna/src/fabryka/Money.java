package fabryka;

public class Money {

	private double payment;

	public Money(double _payment) {
		setPayment(_payment);
	}

	public Money(int hours, double payRate) {
		setPayment(hours * payRate);
	}

	public double getPayment() {
		return payment;
	}

	public void setPayment(double payment) {
		this.payment = payment;
	}
}

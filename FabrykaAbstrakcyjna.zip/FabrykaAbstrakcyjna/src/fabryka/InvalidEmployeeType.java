package fabryka;

public class InvalidEmployeeType extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4764911399957726722L;

	public InvalidEmployeeType(int unrecognizedType)
	{
		setMessage("Unrecognized Type: " + unrecognizedType);
	}

	public void setMessage(String message) {
		this.setMessage(message);
	}
}

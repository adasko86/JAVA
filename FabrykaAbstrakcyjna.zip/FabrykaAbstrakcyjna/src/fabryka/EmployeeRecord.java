package fabryka;

public class EmployeeRecord {
	private int type = -1;

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}
}

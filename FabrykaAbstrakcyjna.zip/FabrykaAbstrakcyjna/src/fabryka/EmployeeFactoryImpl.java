package fabryka;

public class EmployeeFactoryImpl  implements EmployeeFactory 
{
	 public Employee makeEmployee(EmployeeRecord r) throws InvalidEmployeeType 
	 {
		 switch (r.getType()) 
		 {
			 case EmplyeType.COMMISSIONED:
				 return new CommissionedEmployee(r) ;
			 case EmplyeType.HOURLY:
				 return new HourlyEmployee(r);
			 case EmplyeType.SALARIED:
				 return new SalariedEmploye(r);
			 default:
				 throw new InvalidEmployeeType(r.getType());
		 }
	}
}

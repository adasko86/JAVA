package fabryka;

public class EmplyeType {
	public static final int COMMISSIONED = 1;
    public static final int HOURLY = 2;
    public static final int SALARIED = 3;
}

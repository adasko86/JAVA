package fabryka;

public class HourlyEmployee extends Employee {
	EmployeeRecord employeeRecord = null;
	public HourlyEmployee(EmployeeRecord record) {
		employeeRecord = record;
	}
	Money money;
	public Money getMoney() {
		return money;
	}

	public void setMoney(Money _money) {
		this.money = _money;
	}
	@Override
	public boolean isPayday() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Money calculatePay() {
		// TODO Auto-generated method stub
		setMoney(new Money(55, 10.50));
		return this.money;
	}

	@Override
	public void deliverPay() {
		// TODO Auto-generated method stub
		System.out.println("Wyp�a�: " + getMoney().getPayment()  + " z�otych");
	}

}

package fabryka;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeFactoryImpl factoryImpl = new EmployeeFactoryImpl();
		EmployeeRecord empRecord = new EmployeeRecord();
		empRecord.setType(EmplyeType.HOURLY);
		try {
			Employee employee = factoryImpl.makeEmployee(empRecord);
			employee.calculatePay();
			employee.deliverPay();

			empRecord.setType(EmplyeType.COMMISSIONED);
			employee = factoryImpl.makeEmployee(empRecord);
			employee.calculatePay();
			employee.deliverPay();
		} catch (InvalidEmployeeType e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

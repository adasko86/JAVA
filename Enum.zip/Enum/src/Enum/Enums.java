package Enum;

public class Enums {
	public enum Difficulty1
	{
	    EASY(0),
	    MEDIUM(11),
	    HARD(2);
	 
	    /**
	     * Value for this difficulty
	     */
	    public final int Value;
	 
	    private Difficulty1(int value)
	    {
	        Value = value;
	    }
	}
	
	public class Difficulty2
	{
	    public static final int EASY= 1;
	    public static final int MEDIUM= 5;
	    public static final int HARD= 10;
	}
}

package Enum;

import Enum.Enums.Difficulty1;
import Enum.Enums.Difficulty2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int difficult = (int)Difficulty1.MEDIUM.Value;
		System.out.println("Difficulty1 value: " + String.valueOf(difficult));
		
		difficult = Difficulty2.MEDIUM;
		System.out.println("Difficulty2 value: " + String.valueOf(difficult));
	}

}
